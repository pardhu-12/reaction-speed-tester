#include<Wire.h>
#include<Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);


const int btn = 13;
const int LED1 = 19;
const int LED2 = 18;
const int LED3 = 17;
const int LED4 = 16;
const int LED5 = 15;

int reactionPhase = 1;
unsigned long startTime;
unsigned long startTime2;
unsigned long reactionTime;
int generatedGAP;


void setup(){
  Serial.begin(115200);

  pinMode(19 , OUTPUT);
  pinMode(18 , OUTPUT);
  pinMode(17 , OUTPUT);
  pinMode(16 , OUTPUT);
  pinMode(15 , OUTPUT);
  pinMode(13 , INPUT_PULLUP);
  
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found!");
    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);

  Serial.println("WELCOME TO F1 REACTION TESTER");
  display.println("press button to start ");
  display.display();

}

void loop(){


if(digitalRead(btn) == LOW){
  if(reactionPhase == 1){
    digitalWrite(LED1 , HIGH);
    delay(1000);
    digitalWrite(LED2 , HIGH);
    delay(1000);
    digitalWrite(LED3 , HIGH);
    delay(1000);
    display.clearDisplay();
    display.setCursor(0, 0);
    display.print("press the button when lights go out");
    display.display();
    digitalWrite(LED4 , HIGH);
    delay(1000);
    digitalWrite(LED5 , HIGH);
    delay(1000);
   generatedGAP = random(1000 , 3000);

   startTime = millis();
    reactionPhase = 2;
    display.clearDisplay();
  }
}

if(reactionPhase == 2){
  if(millis()- startTime >= generatedGAP){
     digitalWrite(LED1 , LOW);
     digitalWrite(LED2 , LOW);
     digitalWrite(LED3 , LOW);
     digitalWrite(LED4 , LOW);
     digitalWrite(LED5 , LOW);

     startTime2 = millis();       
     reactionPhase = 3;
  }
}

if(reactionPhase == 3){
  if(digitalRead(btn) == LOW){
    reactionTime = millis() - startTime2 ;
    display.setCursor(0, 0);
    display.print("reaction TIME : ");
    display.print(reactionTime);
    display.print("ms");
    display.display(); 

    delay(3000);

     resetGame();
  }
}
}
void resetGame() {
  reactionPhase = 1;
  
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("press button to start ");
  display.display();
 
  while(digitalRead(btn) == LOW) { delay(10); } 
}
